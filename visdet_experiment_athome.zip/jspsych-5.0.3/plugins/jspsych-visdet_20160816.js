/* jspsych-text.js
 * Josh de Leeuw
 *
 * This plugin displays text (including HTML formatted strings) during the experiment.
 * Use it to show instructions, provide performance feedback, etc...
 *
 * documentation: docs.jspsych.org
 *
 *
 */

jsPsych.plugins["visdet"]  = (function() {

  var plugin = {};

  plugin.trial = function(display_element, trial) {

    trial.cont_key = trial.cont_key || [];

    // if any trial variables are functions
    // this evaluates the function and replaces
    // it with the output of the function
    trial = jsPsych.pluginAPI.evaluateFunctionParameters(trial);
    console.log('trial parameters (in visdet):');
    console.log(trial);

    // set the HTML of the display target to replaced_text.
	//display_element.html(trial.text);
	display_element.append($('<img>', {
		src: trial.stimulus,
		id: 'jspsych-button-response-stimulus',
		class: 'block-center'
	}));

    // this array holds handlers from setTimeout calls
    // that need to be cleared if the trial ends early
    var setTimeoutHandlers = [];

    // store response
    var response = {
      rt: -1,
      key: -1
    };
    var after_response = function(info) {

      display_element.html(''); // clear the display
      console.log('after_response var');
      console.log(Date.now());
      
      var trialdata = {
        "rt": info.rt,
        "key_press": info.key
      }

     if (trial.response_ends_trial) {
        end_trial();
      }
    };

    var mouse_listener = function(e) {

      var rt = (new Date()).getTime() - start_time;
      console.log('end in mouse listener');
      console.log(Date.now());

      display_element.unbind('click', mouse_listener);

		response.rt = rt;
		response.key = 'mouse';
      after_response({
        key: 'mouse',
        rt: rt
      });
      console.log('Ive been clicked')

    };

    // check if key is 'mouse'
    if (trial.cont_key == 'mouse') {
      display_element.click(mouse_listener);
      var start_time = (new Date()).getTime();
    } else {
      jsPsych.pluginAPI.getKeyboardResponse({
        callback_function: after_response,
        valid_responses: trial.cont_key,
        rt_method: 'date',
        persist: false,
        allow_held_key: false
      });
    }

    // function to end trial when it is time
    function end_trial() {

      // kill any remaining setTimeout handlers
      for (var i = 0; i < setTimeoutHandlers.length; i++) {
        clearTimeout(setTimeoutHandlers[i]);
      }

      // gather the data to store for the trial
      var trial_data = {
        "rt": response.rt,
        "stimulus": trial.stimulus,
        "key": response.key
      };
      console.log(trial_data.stimulus);
      console.log(trial_data.rt);
      console.log(trial_data.key);

      // clear the display
      display_element.html('');

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    };

    // start timing
    //start_time = Date.now();

    // hide image if timing is set
    if (trial.timing_stim > 0) {
      var t1 = setTimeout(function() {
        $('#jspsych-button-response-stimulus').css('visibility', 'hidden');
      }, trial.timing_stim);
      setTimeoutHandlers.push(t1);
    }

    // end trial if time limit is set
    if (trial.timing_response > 0) {
      var t2 = setTimeout(function() {
        end_trial();
      }, trial.timing_response);
      setTimeoutHandlers.push(t2);
    }

  }; // end of trial definition

  return plugin;
})();
