/**
 * jspsych-survey-likert
 * a jspsych plugin for measuring items on a likert scale
 *
 * Josh de Leeuw
 *
 * documentation: docs.jspsych.org
 * adapted by Joost Wegman
 */

jsPsych.plugins['survey-likert-required'] = (function() {

  var plugin = {};

  plugin.trial = function(display_element, trial) {

    // default parameters for the trial
    trial.preamble = typeof trial.preamble === 'undefined' ? "" : trial.preamble;
    trial.required = typeof trial.required == 'undefined' ? null : trial.required;

    // if any trial variables are functions
    // this evaluates the function and replaces
    // it with the output of the function
    trial = jsPsych.pluginAPI.evaluateFunctionParameters(trial);

    // show preamble text
    display_element.append($('<div>', {
      "id": 'jspsych-survey-likert-preamble',
      "class": 'jspsych-survey-likert-preamble'
    }));

    $('#jspsych-survey-likert-preamble').html(trial.preamble);

    display_element.append('<form id="jspsych-survey-likert-form">');
    // add likert scale questions
    for (var i = 0; i < trial.questions.length; i++) {
      form_element = $('#jspsych-survey-likert-form');
      // add question
      form_element.append('<label class="jspsych-survey-likert-statement">' + trial.questions[i] + '</label>');
      // add options
      var width = 100 / trial.labels[i].length;
      options_string = '<ul class="jspsych-survey-likert-opts" data-radio-group="Q' + i + '">';
      for (var j = 0; j < trial.labels[i].length; j++) {
              // modification1: I added "required"
        options_string += '<li style="width:' + width + '%"><input type="radio" name="Q' + i + '" value="' + j + '" required><label class="jspsych-survey-likert-opt-label">' + trial.labels[i][j] + '</label></li>';
      }
      options_string += '</ul>';
      form_element.append(options_string);
    }

        // modification2
    form_element.append($('<input>', {
      'type': 'submit',
      'class': 'jspsych-survey-likert jspsych-btn',
      'value': 'Submit Answers'
    }));

	form_element.submit(function(event) { // modified to check whether all required questions were answered

     event.preventDefault(); // prevent default action of event

          // measure response time
      var endTime = (new Date()).getTime();
      var response_time = endTime - startTime;
	var carryOn = true;
      // create object to hold responses
      var question_data = {};
      $("#jspsych-survey-likert-form .jspsych-survey-likert-opts").each(function(index) {
        var id = $(this).data('radio-group');
        console.log("id: "+id+". index:"+index + ", required :" + trial.required);
        var response = $('input[name="' + id + '"]:checked').val();
        if (trial.required && trial.required[index] & typeof response == 'undefined') {
        
            //alert("Required field should not be blank.");
			$(this).focus();
			carryOn = false; // prevent trial finish later on
			
            //return false;
          response = -1;
        }
        
        var obje = {};
        obje[id] = response;
//        if (carryOn==false) {event.stopPropagation();};
        $.extend(question_data, obje);
      });

      // save data
      var trial_data = {
        "rt": response_time,
        "responses": JSON.stringify(question_data)
      };

	if (carryOn==true) {
      display_element.html('');

      // next trial
      jsPsych.finishTrial(trial_data);}
      else {form_element.append("Please answer all questions");}
    });

    var startTime = (new Date()).getTime();
  };

  return plugin;
})();